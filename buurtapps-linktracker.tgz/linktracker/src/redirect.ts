import type { FastifyInstance, FastifyRequest } from 'fastify';
import type { Cache } from './cache.js';
import type { KlikWachtrij } from './wachtrij.js';
import { normaliseerBron } from './config.js';

const ID = /^[A-Za-z0-9]{8}$/;

function hostZonderPoort(req: FastifyRequest): string {
  return (req.headers.host ?? '').trim().toLowerCase().replace(/:\d+$/, '');
}

export function registreerRedirect(app: FastifyInstance, cache: Cache, wachtrij: KlikWachtrij, standaardFallback: string) {
  app.route({
    method: ['GET', 'HEAD'],
    url: '/r/:id',
    config: { rateLimit: { groupId: 'redirect' } } as never,
    handler: async (req, reply) => {
      reply.header('Cache-Control', 'no-store, max-age=0');
      reply.header('Referrer-Policy', 'no-referrer-when-downgrade');
      reply.header('X-Robots-Tag', 'noindex, nofollow');
      const id = (req.params as { id: string }).id;
      const host = hostZonderPoort(req);
      const hostApp = cache.appsPerDomein.get(host);
      const fallback = hostApp?.fallbackUrl ?? standaardFallback;

      if (!ID.test(id)) {
        wachtrij.tellers.onbekend_id++;
        return reply.redirect(fallback, 302);
      }

      let link;
      try {
        link = await cache.zoek(id);
      } catch {
        // Database onbereikbaar en link niet in cache: gebruiker niet laten hangen
        return reply.redirect(fallback, 302);
      }
      if (!link) {
        wachtrij.tellers.onbekend_id++;
        return reply.redirect(fallback, 302);
      }

      let doel = link.doelUrl;
      let classificatie: 'normaal' | 'inactief' | 'domein_mismatch' | 'neutrale_host' = 'normaal';
      const linkApp = cache.apps.get(link.appId);

      if (!link.actief) {
        classificatie = 'inactief';
        doel = linkApp?.fallbackUrl ?? fallback;
      } else if (hostApp && hostApp.id !== link.appId) {
        // Link van app A via domein van app B: niet doorsturen naar de bestemming
        classificatie = 'domein_mismatch';
        doel = hostApp.fallbackUrl;
      } else if (!hostApp) {
        // Bijv. het *.up.railway.app-adres vóór DNS: doorsturen, maar herkenbaar registreren
        classificatie = 'neutrale_host';
      }

      // Redirectlus voorkomen: bestemming mag nooit naar een eigen redirectdomein wijzen
      try {
        const doelHost = new URL(doel).hostname.toLowerCase();
        if (cache.appsPerDomein.has(doelHost)) doel = linkApp?.fallbackUrl ?? fallback;
      } catch {
        doel = fallback;
      }

      if (req.method === 'HEAD') {
        wachtrij.tellers.head++;
      } else {
        const b = normaliseerBron((req.query as { b?: string }).b);
        wachtrij.plaats({
          linkId: link.id,
          appId: link.appId,
          ts: new Date(),
          ip: req.ip,
          ua: req.headers['user-agent'],
          bron: b,
          classificatie,
        });
      }
      return reply.redirect(doel, 302);
    },
  });
}
